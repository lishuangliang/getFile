/**
 * Created by tarena on 18-10-20.
 */


console.log('test2.js')